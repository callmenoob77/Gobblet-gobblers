#include <graphics.h>
#include <iostream>
#include <cstdlib>
#include "grafica.cpp"
#define MAX 20
#define YELLOW2 RGB(242,121,121)
using namespace std;

int frecPiese[MAX]= {0,2,2,2,2,2,2};
int x1tabla=maxx/2-dim/2, y1tabla=maxy/2-dim/2,x2tabla=maxx/2+dim/2, y2tabla=maxy/2+dim/2;
int piesaselectata=0, piesaplasata=0, memorie;
int ok=0, turn=1, win=0;
int proMODE=0;
int score=0, scoremax=0, ac=0, bc=0, kc;

struct piesa {
    int valoare;
    int x1, y1, x2, y2;

}v[MAX];

struct matrice {
    int x1, y1, x2, y2;
    int index=0;
    int adancime[MAX];   // retine piesele de sub
}tabla[MAX][MAX];

// functii play vs computer
void joccomputer(int x, int y);
void detectarecomp(int& pozComputer, int &a, int &b);
void detectareplayer(int& pozPlayer, int &a, int &b);
void castigatC(int &castigator);
void mutareRandom (int& ok1);
void desencastig();
void scr(int&a, int& b,int k, int &score);
int cpiece(int i, int j);
int cpiece2(int i, int j, int num);
void castigplayer(int pozPlayer, int a1, int b1);
void alegepiesa(int p, int& a, int& b);

//functii generale joc
void clearpatrat(int i, int j);
void gasestexytab(int &x,int &y);
int gasesteVec(int x, int y);
void departajareMatrice();
void initializare();
void departajarePiese();
void joc(int x, int y);
void incepejoc();
void init();
void grafica();
void meniu_principal();
void castigat();
void valoarePiese();
void ecranCastigator(int castigator);
void meniubara();
void meniu_principalCLICK(int x, int y);
//
void eroare();
void tutorial();
void sageata(int x, int y);
void you_won(int x);
void you_wonCLICK(int x, int y);
void opponent(int x, int y);
void TablaJoc();
void credits();
void sagetutza_player_1(int x, int y);
void sagetutza_player_2(int x, int y);
void chenar_dreapta(int poz, bool evidentiaza);
void chenar_stanga(int poz, bool evidentiaza);
void NumarPiese(int numar, int poz);
void DesenareChenarPiese();
void sageata_pentru_joc(int x, int y);
void sageata_pentru_joc_desen();



bool language_folosit = 0;
int playerone = 0, playertwo = 1;
int t[6], u[6];
void buton(char s[], int dist);
void player1_player2(char s[], int dist);
void buton_joaca_meniu_principal(char *s, int xa, int ya, int dist_buton, int xb, int yb);

int main()
{

    Window();
    meniu_principal();
    getch();
}
void graficaoponent ()
{

    setbkcolor(YELLOW2);
    cleardevice();
    setbkcolor(YELLOW2);


    ///             sageata
    int wxh = 360;
    int ya = maxy/12;
    int yb = maxy/12 + wxh/8;
    readimagefile("sageata2.jpg", ya, ya, yb, yb);
    rectangle(ya, ya, yb, yb);

    ///             textul de pe pagina
    ///text centru -> Select your player
    settextstyle(BOLD_FONT, 0, 6);
    char *s;
    if(language_folosit == 0)
    {
        s = "Select your opponent:";
    }
    else
        s = "Alegeti adversarul:";
    int wselect = textwidth(s);
    int hselect = textheight(s);
    outtextxy(maxx/2 - wselect/2, maxy/4 - hselect/2, s);


    ///text centru -> versus
    wselect = textwidth("VS");
    hselect = textheight("VS");
    outtextxy(maxx/2 - wselect/2, maxy/2 - hselect/2, "VS");


    settextstyle(BOLD_FONT, 0, 6);
    setbkcolor(BLACK);
    setcolor(WHITE);
    if(language_folosit == 0)
        s = "Play";
    else
        s = "Joaca";
    wselect = textwidth(s);
    hselect = textheight(s);
    setfillstyle(1, BLACK);
    bar(maxx/2 - (wselect*3/4), maxy/4*3 - (hselect*3/4), maxx/2 + (wselect*3/4), maxy/4*3 + (hselect*3/4));
    outtextxy(maxx/2 - wselect/2, maxy/4*3 - hselect/2, s);
    rectangle(maxx/2 - (wselect*3/4), maxy/4*3 - (hselect*3/4), maxx/2 + (wselect*3/4), maxy/4*3 + (hselect*3/4));

    ///             butoanele de pe pagina
    if(language_folosit == 0)
        buton("Human", 1);
    else
        buton("Om", 1);
    if(language_folosit == 0)
        player1_player2("Player 1:", 1);
    else
        player1_player2("Jucatorul 1:", 1);



    if(language_folosit == 0)
        buton("Computer: Easy", 3);
    else
        buton("Calculator: Usor", 3);
    int v3[6];
    int u3[6];
    v3[0] = t[0];
    v3[1] = t[1];
    v3[2] = t[2];
    v3[3] = t[3];
    v3[4] = t[4];
    v3[5] = t[5];
    u3[0] = u[0];
    u3[1] = u[1];
    u3[2] = u[2];
    u3[3] = u[3];
    u3[4] = u[4];
    u3[5] = u[5];
    if(language_folosit == 0)
        player1_player2("Player 2:", 3);
    else
        player1_player2("Jucatorul 2:", 3);

    setfillstyle(1, BLACK);
    setbkcolor(9);
}

void opponent(int x, int y)
{
    setbkcolor(YELLOW2);
    cleardevice();


    ///             sageata
    int wxh = 360;
    int ya = maxy/12;
    int yb = maxy/12 + wxh/8;
    setcolor(BLACK);
    readimagefile("sageata2.jpg", ya, ya, yb, yb);
    rectangle(ya, ya, yb, yb);

    ///             textul de pe pagina
    ///text centru -> Select your player
    settextstyle(BOLD_FONT, 0, 6);
    char *s;
    if(language_folosit == 0)
    {
        s = "Select your opponent:";
    }
    else
        s = "Alegeti adversarul:";
    int wselect = textwidth(s);
    int hselect = textheight(s);
    outtextxy(maxx/2 - wselect/2, maxy/4 - hselect/2, s);


    ///text centru -> versus
    wselect = textwidth("VS");
    hselect = textheight("VS");
    outtextxy(maxx/2 - wselect/2, maxy/2 - hselect/2, "VS");


    settextstyle(BOLD_FONT, 0, 6);
    setbkcolor(BLACK);
    setcolor(WHITE);
    if(language_folosit == 0)
        s = "Play";
    else
        s = "Joaca";
    wselect = textwidth(s);
    hselect = textheight(s);
    setfillstyle(1, BLACK);
    bar(maxx/2 - (wselect*3/4), maxy/4*3 - (hselect*3/4), maxx/2 + (wselect*3/4), maxy/4*3 + (hselect*3/4));
    outtextxy(maxx/2 - wselect/2, maxy/4*3 - hselect/2, s);
    rectangle(maxx/2 - (wselect*3/4), maxy/4*3 - (hselect*3/4), maxx/2 + (wselect*3/4), maxy/4*3 + (hselect*3/4));

    ///             butoanele de pe pagina
    if(language_folosit == 0)
        buton("Human", 1);
    else
        buton("Om", 1);
    if(language_folosit == 0)
        player1_player2("Player 1:", 1);
    else
        player1_player2("Jucatorul 1:", 1);



    if(language_folosit == 0)
        buton("Computer: Easy", 3);
    else
        buton("Calculator: Usor", 3);
    int v3[6];
    int u3[6];
    v3[0] = t[0];
    v3[1] = t[1];
    v3[2] = t[2];
    v3[3] = t[3];
    v3[4] = t[4];
    v3[5] = t[5];
    u3[0] = u[0];
    u3[1] = u[1];
    u3[2] = u[2];
    u3[3] = u[3];
    u3[4] = u[4];
    u3[5] = u[5];
    if(language_folosit == 0)
        player1_player2("Player 2:", 3);
    else
        player1_player2("Jucatorul 2:", 3);

    setfillstyle(1, BLACK);
    setbkcolor(9);
    int mx = x;
    int my = y;

    if(mx >= v3[2] && mx <= v3[0] && my >= v3[1] && my <= v3[5])
    {
        if(playertwo == 0)
        {
            if(language_folosit == 0)
            {
                buton("Computer: Hard", 3);
            }
            else
            {
                buton("Calculator: Greu", 3);
            }
            playertwo = 2;
        }
        else
        {
            if(playertwo == 1)
            {
                if(language_folosit == 0)
                        buton("Human", 3);
                    else
                        buton("Om", 3);
                playertwo = 0;
            }
            else
            {
                if(language_folosit == 0)
                        buton("Computer: Easy", 3);
                    else
                        buton("Calculator: Usor", 3);
                playertwo = 1;
            }
        }
        delay(200);
    }

    if(mx >= u3[0] && mx <= u3[2] && my >= u3[1] && my <= u3[5])
    {
        if(playertwo == 0)
        {
            if(language_folosit == 0)
            {
                buton("Computer: Easy", 3);
            }
            else
            {
                buton("Calculator: Usor", 3);
            }
            playertwo = 1;
        }
        else
        {
            if(playertwo == 1)
            {
                if(language_folosit == 0)
                        buton("Computer: Hard", 3);
                    else
                        buton("Calculator: Greu", 3);
                playertwo = 2;
            }
            else
            {
                if(language_folosit == 0)
                        buton("Human", 3);
                    else
                        buton("Om", 3);
                playertwo = 0;
            }
        }
        delay(200);
    }
    if(mx >= maxx/2 - (wselect*3/4) && my >= maxy/4*3 - (hselect*3/4) && mx <= maxx/2 + (wselect*3/4) && my <= maxy/4*3 + (hselect*3/4))
    {
        cleardevice();
        if (playertwo == 0)
        {
            grafica();
            init();
            incepejoc();
        }
        else if (playertwo==1)
        {
            grafica();
            init();
            registermousehandler(WM_LBUTTONDOWN,joccomputer);
        }
        else if (playertwo==2) {
            proMODE=1;
            grafica();
            init();
            registermousehandler(WM_LBUTTONDOWN,joccomputer);
        }
    }
    if(mx >= ya && mx <= yb && my >= ya && my <= yb) ///buton catre tabla de joc
    {
        cleardevice();
        meniu_principal();
    }

}
void buton(char s[], int dist)
{
    setbkcolor(BLACK);
    settextstyle(BOLD_FONT, 0, maxy/179);
    int wselect = textwidth(s);
    int hselect = textheight(s);
    setcolor(WHITE);

    setfillstyle(1, BLACK);
    bar(maxx / 4 * dist - (maxx/6) - 2, maxy/2 - hselect/2 - 2, maxx/4 * dist + (maxx/6) + 2, maxy/2 + hselect/2 + 2);

    ///patrat mare
    rectangle(maxx / 4 * dist - (maxx/6) - 2, maxy/2 - hselect/2 - 2, maxx/4 * dist + (maxx/6) + 2, maxy/2 + hselect/2 + 2);


    ///patrat sageata stanga
    rectangle(maxx / 4 * dist - (maxx/6) - 2, maxy/2 - hselect/2 - 2, maxx / 4 * dist - (maxx/6) + 2 + hselect, maxy/2 + hselect/2 + 2);
    t[0] = maxx / 4 * dist - (maxx/6) + 2 + hselect;
    t[1] = maxy/2 - hselect/2 - 2;
    t[2] = maxx / 4 * dist - (maxx/6) - 2;
    t[3] = maxy/2;
    t[4] = maxx / 4 * dist - (maxx/6) + 2 + hselect;
    t[5] = maxy/2 + hselect/2 + 2;
    drawpoly(3, t);

    ///patrat sageata dreapta
    rectangle(maxx/4 * dist + (maxx/6) - 2 - hselect, maxy/2 - hselect/2 - 2, maxx/4 * dist + (maxx/6) + 2, maxy/2 + hselect/2 + 2);
    u[0] = maxx/4 * dist + (maxx/6) - 2 - hselect;
    u[1] = maxy/2 - hselect/2 - 2;
    u[2] = maxx/4 * dist + (maxx/6) + 2;
    u[3] = maxy/2;
    u[4] = maxx/4 * dist + (maxx/6) - 2 - hselect;
    u[5] = maxy/2 + hselect/2 + 2;
    drawpoly(3, u);

    outtextxy(maxx/4 * dist - wselect/2, maxy/2 - hselect/2, s);
}

void player1_player2(char s[], int dist) ///scrisul "player 1" si "player 2" de pe pagina in care alegi pc vs pc
{
    setbkcolor(YELLOW2);
    settextstyle(BOLD_FONT, 0, maxy/179);
    int wselect = textwidth(s);
    int hselect = textheight(s);
    setcolor(BLACK);
    outtextxy(maxx/4 * dist - wselect / 2, maxy/2 - (hselect * 5 / 2), s);

}
void sagetutza_player_1(int x, int y)
{
    setcolor(BLACK);
    line(x, y, x + 40, y);
    line(x, y + 1, x + 40, y + 1);
    line(x, y - 1, x + 40, y - 1);

    line(x, y, x + 20, y - 10);
    line(x, y - 1, x + 20, y - 11);
    line(x, y + 1, x + 20, y - 9);

    line(x, y, x + 20, y + 10);
    line(x, y + 1, x + 20, y + 11);
    line(x, y - 1, x + 20, y + 9);
}

void sagetutza_player_2(int x, int y)
{
    setcolor(BLACK);
    line(x, y, x - 40, y);
    line(x, y + 1, x - 40, y + 1);
    line(x, y - 1, x - 40, y - 1);

    line(x, y, x - 20, y - 10);
    line(x, y - 1, x - 20, y - 11);
    line(x, y + 1, x - 20, y - 9);

    line(x, y, x - 20, y + 10);
    line(x, y + 1, x - 20, y + 11);
    line(x, y - 1, x - 20, y + 9);
}
void meniu_principal()
{
    ///int w = textwidth("Gobblet Gobblers");
    ///int h = textheight("Gobblet Gobblers");
    ///outtextxy(maxx/2-w/2, maxy/4 - h/2, "Gobblet Gobblers");
    setbkcolor(YELLOW2);
    cleardevice();


    ///imagine meniu principal
    int w = maxx/1.59875;
    int h = maxy/1.728365;
    readimagefile("poza_main.jpg", maxx/2 - w/3 - 2, maxy/4 - h/3 - 2, maxx/2 + w/3 + 2, maxy/4 + h/3 + 2);
    setcolor(WHITE);
    rectangle(maxx/2 - w/3 - 2, maxy/4 - h/3 - 2, maxx/2 + w/3 + 2, maxy/4 + h/3 + 2);


    ///butoane meniu principal - coordonate
    setcolor(BLACK);
    int xa = maxx/2-w/8-2;
    int xb = maxx/2+w/8+2;
    int ya = maxy/4-h/14-2;
    int yb = maxy/4+h/14+2;
    int dist_buton = maxy/16;
    ya+=maxy/4;
    yb+=maxy/4;

    ///scris butoane
    settextstyle(BOLD_FONT, HORIZ_DIR, 4);
    setbkcolor(WHITE);
    setfillstyle(1, WHITE);

    ///primul buton
    buton_joaca_meniu_principal("PLAY", xa, ya, dist_buton, xb, yb);


    ///al doilea buton
    bar(xa, ya + dist_buton * 3, xb, yb + dist_buton * 3);
    rectangle(xa, ya + dist_buton * 3, xb, yb + dist_buton * 3);
    int wTUTORIAL = textwidth("TUTORIAL");
    int hTUTORIAL = textheight("TUTORIAL");
    outtextxy((xa+xb)/2 - wTUTORIAL/2, (ya + yb) / 2 + dist_buton * 3 - hTUTORIAL/2, "TUTORIAL");

    ///al treilea buton
    rectangle(xa, ya + dist_buton * 5, xb, yb + dist_buton * 5);
    if(language_folosit == 1)
    {
        readimagefile("steag_ro.jpg",xa + 1, ya + dist_buton * 5+1, xb - 1, yb + dist_buton * 5-1);
        buton_joaca_meniu_principal("JOACA", xa, ya, dist_buton, xb, yb);
    }
    else
    {
        readimagefile("steag_uk.jpg",xa + 1, ya + dist_buton * 5+1, xb - 1, yb + dist_buton * 5-1);
        buton_joaca_meniu_principal("PLAY", xa, ya, dist_buton, xb, yb);
    }


    registermousehandler(WM_LBUTTONDOWN, meniu_principalCLICK);
}
void meniu_principalCLICK(int x, int y){

    ///butoane meniu principal - coordonate
    setcolor(BLACK);
    int w = maxx/1.59875;
    int h = maxy/1.728365;
    int xa = maxx/2-w/8-2;
    int xb = maxx/2+w/8+2;
    int ya = maxy/4-h/14-2;
    int yb = maxy/4+h/14+2;
    int dist_buton = maxy/16;
    ya+=maxy/4;
    yb+=maxy/4;
    int mx = x;
    int my = y;
            if(mx >= xa && mx<=xb && my >= ya + dist_buton * 1 && my <= yb + dist_buton * 1) ///buton catre tabla de joc
            {   setbkcolor(12);
                cleardevice();
                graficaoponent();
                registermousehandler(WM_LBUTTONDOWN,opponent);
                //you_won();
            }
            if(mx >= xa && mx<=xb && my >= ya + dist_buton * 3 && my <= yb + dist_buton * 3) ///buton catre tutorial -> momentan nu e facut
            {
                setbkcolor(12);
                cleardevice();
                tutorial();
            }
            if(mx >= xa && mx<=xb && my >= ya + dist_buton * 5 && my <= yb + dist_buton * 5) ///buton catre tutorial -> momentan nu e facut
            {
                if(language_folosit == 0)
                    {
                        readimagefile("steag_ro.jpg",xa + 1, ya + dist_buton * 5+1, xb - 1, yb + dist_buton * 5-1);
                        buton_joaca_meniu_principal("JOACA", xa, ya, dist_buton, xb, yb);
                    }
                else
                    {
                        readimagefile("steag_uk.jpg",xa + 1, ya + dist_buton * 5+1, xb - 1, yb + dist_buton * 5-1);
                        buton_joaca_meniu_principal("PLAY", xa, ya, dist_buton, xb, yb);
                    }
                language_folosit = 1 - language_folosit;
                delay(200);
            }
}


void buton_joaca_meniu_principal(char *s, int xa, int ya, int dist_buton, int xb, int yb)
{
    rectangle(xa, ya + dist_buton * 1, xb, yb + dist_buton * 1);
    int wPLAY = textwidth(s);
    int hPLAY = textheight(s);
    bar(xa+1, ya + dist_buton * 1+1, xb, yb + dist_buton * 1);
    outtextxy((xa+xb)/2 - wPLAY / 2, (ya + yb) / 2 + dist_buton * 1 - hPLAY / 2, s);
}
void tutorial()
{
    setbkcolor(YELLOW2);
    cleardevice();
    setbkcolor(YELLOW2);
    ///titlurile din tutorial
    settextstyle(BOLD_FONT, HORIZ_DIR, 4);
    setfillstyle(1, BLACK);

    if(language_folosit == 0)
    {

    int wHTW = textwidth("How to win");
    int hHTW = textheight("How to win");
    outtextxy(maxx/6 * 1 - wHTW/2, maxy/4 - hHTW/2, "How to win");
    bar(maxx/6 * 1 - wHTW / 2 - 2, maxy/4 + hHTW / 2 + 2, maxx/6 * 1 + wHTW / 2 + 2, maxy/4 + hHTW / 2 + 4);

    int wHTP = textwidth("How to play");
    int hHTP = textheight("How to play");
    outtextxy(maxx/6 * 3 - wHTP/2, maxy/4 - hHTP/2, "How to play");
    bar(maxx/6 * 3 - wHTP / 2 - 2, maxy/4 + hHTP / 2 + 2, maxx/6 * 3 + wHTP / 2 + 2, maxy/4 + hHTP / 2 + 4);

    int wTAS = textwidth("Tips and strategy");
    int hTAS = textheight("Tips and strategy");
    outtextxy(maxx/6 * 5 - wTAS/2, maxy/4 - hTAS/2, "Tips and strategy");
    bar(maxx/6 * 5 - wTAS / 2 - 2, maxy/4 + hTAS / 2 + 2, maxx/6 * 5 + wTAS / 2 + 2, maxy/4 + hTAS / 2 + 4);

    ///instructiunile de joc
    ///how to win
    settextstyle(8, HORIZ_DIR, 1);
    int wTTT = textwidth("Like Tic-Tac-Toe, you");
    int hTTT = textheight("Like Tic-Tac-Toe, you");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3, "Like Tic-Tac-Toe, you");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 3 / 2, "must be the first");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 3, "player to get 3 pieces");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 9 / 2, "in a row to win.");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 6, "You win by completing");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 15 / 2, "a line, a row or a diagonal.");

    ///how to play
    int wTITYCE = textwidth("Then, in turn, you can either:");
    outtextxy(maxx/6 * 3 - wTITYCE/2, maxy/8 * 3 + hTTT * 3 / 2, "Then, in turn, you can either:");

    outtextxy(maxx/6 * 3 - wTITYCE/2, maxy/8 * 3, "Each player chooses a color.");

    int wPAGOTB = textwidth("1. Put a Gobbler on the board,");
    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 7 / 2, "1. Put a Gobbler on the board,");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 9 / 2, "   on an empty space");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 11 / 2, "   or over a smaller Gobbler");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 15 / 2, "2. Move one of your Gobblers");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 17 / 2, "   already on the board to");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 19 / 2, "   an empty space or over");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 21 / 2, "   a smaller Gobbler.");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 23 / 2, "   Once you click on a Gobbler");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 25 / 2, "   you must move it.");

    ///Tips and strategy

    int wDNHTGUYOP = textwidth("2. Do not hesitate to gobble aaaaup");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 3, "2. Do not hesitate to gobble up");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 4, "   your oponent's pieces.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3, "1. You don't have to start");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT, "   with your bigger pieces.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 6, "3. You can gobble up");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 7, "   your own pieces.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 9, "4. You can gobble up any");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 10, "   smaller Gobbler.");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 11, "   It doesn't have to be");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 12, "   the next size down.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 14, "5. Always look at what");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 15, "   your opponent is doing,");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 16, "   think ahead and have fun!!");

    }
    else
    {
    int wHTW = textwidth("Cum se castiga?");
    int hHTW = textheight("Cum se castiga?");
    outtextxy(maxx/6 * 1 - wHTW/2, maxy/4 - hHTW/2, "Cum se castiga?");
    bar(maxx/6 * 1 - wHTW / 2 - 2, maxy/4 + hHTW / 2 + 2, maxx/6 * 1 + wHTW / 2 + 2, maxy/4 + hHTW / 2 + 4);

    int wHTP = textwidth("Cum se joaca?");
    int hHTP = textheight("Cum se joaca?");
    outtextxy(maxx/6 * 3 - wHTP/2, maxy/4 - hHTP/2, "Cum se joaca?");
    bar(maxx/6 * 3 - wHTP / 2 - 2, maxy/4 + hHTP / 2 + 2, maxx/6 * 3 + wHTP / 2 + 2, maxy/4 + hHTP / 2 + 4);

    int wTAS = textwidth("Sfaturi si strategii");
    int hTAS = textheight("Sfaturi si strategii");
    outtextxy(maxx/6 * 5 - wTAS/2, maxy/4 - hTAS/2, "Sfaturi si strategii");
    bar(maxx/6 * 5 - wTAS / 2 - 2, maxy/4 + hTAS / 2 + 2, maxx/6 * 5 + wTAS / 2 + 2, maxy/4 + hTAS / 2 + 4);


    ///instructiunile de joc
    ///how to win
    settextstyle(8, HORIZ_DIR, 1);
    int wTTT = textwidth("Asemenea jocului X si 0,");
    int hTTT = textheight("Asemenea jocului X si 0,");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3, "Asemenea jocului X si 0,");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 3 / 2, "trebuie sa fii primul");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 3, "jucator care pune 3 piese");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 9 / 2, "consecutive, de aceeasi");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 6, "culoare, intr-o linie.");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 15 / 2, "Castigi completand ori");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 9, "o linie, ori o coloana");

    outtextxy(maxx/6 * 1 - wTTT/2, maxy/8 * 3 + hTTT * 21 / 2, "ori o diagonala.");

    ///how to play
    int wTITYCE = textwidth("Fiecare jucator alege o culoare.");

    outtextxy(maxx/6 * 3 - wTITYCE/2, maxy/8 * 3, "Fiecare jucator alege o culoare.");

    outtextxy(maxx/6 * 3 - wTITYCE/2, maxy/8 * 3 + hTTT * 3 / 2, "Apoi, o data la tura fiecaruia,");

    outtextxy(maxx/6 * 3 - wTITYCE/2, maxy/8 * 3 + hTTT * 3, "jucatorii pot:");

    int wPAGOTB = textwidth("1. Pune un Gobbler pe tabla,");
    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 5, "1. Pune un Gobbler pe tabla,");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 6, "   intr-un spatiu gol sau");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 7, "   peste un Gobbler mai mic.");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 9, "2. Muta unul dintre Gobbleri");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 10, "   aflat pe tabla pe un");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 11, "   spatiu gol sau peste un");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 12, "   Gobbler mai mic. Odata ce");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 13, "   ai apasat pe un Gobbler");

    outtextxy(maxx/6 * 3 - wPAGOTB/2, maxy/8 * 3 + hTTT * 14, "   esti obligat sa il muti.");

    ///Tips and strategy

    int wDNHTGUYOP = textwidth("2. Do not hesitate to gobble aaaaup");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 3, "2. Nu ezita sa iti pui piesele");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 4, "   peste piesele oponentului.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3, "1. Nu trebuie sa incepi ");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT, "   cu cele mai mari piese.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 6, "3. Iti poti pune propriile");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 7, "   piese peste piesele tale.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 9, "4. Poti pune orice Gobbler");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 10, "   peste un Gobbler mai mic.");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 11, "   Nu trebuie sa fie neaparat");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 12, "   urmatoarea marime mai mica.");

    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 14, "5. Mereu fii atent la");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 15, "   oponentul tau, gandeste");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 16, "   in viitor si, cel mai");
    outtextxy(maxx/6 * 5 - wDNHTGUYOP/2, maxy/8 * 3 + hTTT * 17, "   important, distreaza-te!!");
    }
    int wxh = 360;
    int ya = maxy/12;
    int yb = maxy/12 + wxh/8;
    readimagefile("sageata2.jpg", ya, ya, yb, yb);
    rectangle(ya, ya, yb, yb);
    registermousehandler(WM_LBUTTONDOWN, sageata);
}

void sageata(int x, int y)
{
    int mx = x;
    int my = y;
    int wxh = 360;
    int ya = maxy/12;
    int yb = maxy/12 + wxh/8;
    if(mx >= ya && mx <= yb && my >= ya && my <= yb) ///buton catre tabla de joc
    {
        cleardevice();
        meniu_principal();
    }
}

void you_won(int castigator)
{
    setbkcolor(12);
    cleardevice();
    setbkcolor(12);
    settextstyle(BOLD_FONT, 0, 5);

    int maxx = getmaxx();
    int maxy = getmaxy();

    ///imagine centrala
    int w = maxx/1.59875;
    int h = maxy/1.728365;
    readimagefile("poza_main.jpg", maxx/2 - w/3, maxy/2 - h/3, maxx/2 + w/3, maxy/2 + h/3);
    setcolor(WHITE);
    rectangle(maxx/2 - w/3 - 2, maxy/2 - h/3 - 2, maxx/2 + w/3 + 2, maxy/2 + h/3 + 2);



    setcolor(BLACK);

    ///scris-ul cu felicitari
    char *s;
    if(language_folosit == 0)
        s = "CONGRATULATIONS!!";
    else
        s = "FELICITARI!!";
    int wCONGRATS = textwidth(s);
    int hCONGRATS = textheight(s);
    outtextxy(maxx/2 - wCONGRATS/2, maxy/8, s);

    ///scrisul cu care jucator a castigat
    if(language_folosit == 0 &&castigator==1)
        s = "PLAYER 1 HAS WON!!";
    else if (language_folosit == 0 && castigator==2)
            s = "PLAYER 2 HAS WON!!";
    else if (language_folosit == 1 &&castigator==1)
        s = "JUCATORUL 1 A CASTIGAT!!";
    else if (language_folosit == 1 &&castigator==2)
        s = "JUCATORUL 2 A CASTIGAT!!";

    wCONGRATS = textwidth(s);
    outtextxy(maxx/2 - wCONGRATS/2, maxy/8 + hCONGRATS, s);
    settextstyle(BOLD_FONT, 0, 3);
    setfillstyle(1, WHITE);
    if(language_folosit == 0)
        s = "Play again";
    else
        s = "Joaca din nou";
    wCONGRATS = textwidth(s);
    hCONGRATS = textheight(s);
    bar(maxx / 2 - (wCONGRATS * 3 / 4) - 2, maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2, maxx / 2 + (wCONGRATS * 3 / 4) + 2, maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2);
    rectangle(maxx / 2 - (wCONGRATS * 3 / 4) - 2, maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2, maxx / 2 + (wCONGRATS * 3 / 4) + 2, maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2);
    setbkcolor(WHITE);
    outtextxy(maxx / 2 - wCONGRATS / 2, maxy / 16 * 13 - hCONGRATS / 2, s);

    if(language_folosit == 0)
        s = "Main menu";
    else
        s = "Meniu principal";
    wCONGRATS = textwidth(s);
    hCONGRATS = textheight(s);
    bar(maxx / 4 - (wCONGRATS * 3 / 4) - 2, maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2, maxx / 4 + (wCONGRATS * 3 / 4) + 2, maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2);
    rectangle(maxx / 4 - (wCONGRATS * 3 / 4) - 2, maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2, maxx / 4 + (wCONGRATS * 3 / 4) + 2, maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2);
    outtextxy(maxx / 4 - wCONGRATS/2, maxy / 16 * 13 - hCONGRATS / 2, s);

    if(language_folosit == 0)
        s = "Exit game";
    else
        s = "Iesire din joc";
    wCONGRATS = textwidth(s);
    hCONGRATS = textheight(s);
    bar(maxx / 4 * 3 - (wCONGRATS * 3 / 4) - 2, maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2, maxx / 4 * 3 + (wCONGRATS * 3 / 4) + 2, maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2);
    rectangle(maxx / 4 * 3 - (wCONGRATS * 3 / 4) - 2, maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2, maxx / 4 * 3 + (wCONGRATS * 3 / 4) + 2, maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2);
    outtextxy(maxx / 4 * 3 - wCONGRATS / 2, maxy / 16 * 13 - hCONGRATS / 2, s);

    registermousehandler(WM_LBUTTONDOWN, you_wonCLICK);

}
void you_wonCLICK(int x, int y) {
    char *s;
    if(language_folosit == 0)
        s = "Exit game";
    else
        s = "Iesire din joc";
    int wCONGRATS = textwidth(s);
    int hCONGRATS = textheight(s);
    int mx = x;
    int my = y;
            if(mx >= maxx / 4 * 3 - (wCONGRATS * 3 / 4) - 2 && mx <= maxx / 4 * 3 + (wCONGRATS * 3 / 4) + 2 && my >= maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2 && my <= maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2) ///buton catre tabla de joc
            {
                closegraph();
            }
            if(mx >= maxx / 2 - (wCONGRATS * 3 / 4) - 2 && mx <= maxx / 2 + (wCONGRATS * 3 / 4) + 2 && my >= maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2 && my <= maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2) ///buton catre tabla de joc
            {
                cleardevice();
                grafica();
                init();
                if (playerone==0&&playertwo==0)
                    incepejoc();
                else if (playerone ==0 && playertwo==1)
                    registermousehandler(WM_LBUTTONDOWN,joccomputer);
                    else if(playerone == 0)
                        registermousehandler(WM_LBUTTONDOWN,joccomputer);
            }
            if(mx >= maxx / 4 - (wCONGRATS * 3 / 4) - 2 && mx <= maxx / 4 + (wCONGRATS * 3 / 4) + 2 && my >= maxy / 16 * 13 - (hCONGRATS * 3 / 4) - 2 && my <= maxy / 16 * 13 + (hCONGRATS * 3 / 4) + 2) ///buton catre tabla de joc
            {
                cleardevice();
                meniu_principal();
            }
}

void chenar_stanga(int poz, bool evidentiaza)
{
    int x1tabla=maxx/2-dim/2;
    int y1tabla=maxy/2-dim/2;
    int x2tabla=maxx/2+dim/2;
    int y2tabla=maxy/2+dim/2;
    if(evidentiaza == 1)
        setfillstyle(1, GREEN);
    else
        setfillstyle(1, 11);
    bar(1, y1tabla + dim * (poz - 1) / 3 + 2, 6, y1tabla + dim * poz / 3 - 1); ///laterala stanga
    bar(dim / 3 - 1, y1tabla + dim * (poz - 1) / 3 + 2, dim / 3 - 6, y1tabla + dim * poz / 3 - 32); ///laterala dreapta
    bar(1, y1tabla + dim * (poz - 1) / 3 + 1, dim / 3 - 1, y1tabla + dim * (poz - 1) / 3 + 8); ///sus
    bar(1, y1tabla + dim * poz / 3 - 1, dim / 3 - 32, y1tabla + dim * poz / 3 - 6); ///jos
    bar(dim / 3 - 37, y1tabla + dim * poz / 3 - 4, dim / 3 - 32, y1tabla + dim * poz / 3 - 33); ///patratel mic stanga
    bar(dim / 3 - 37, y1tabla + dim * poz / 3 - 37, dim / 3 - 1, y1tabla + dim * poz / 3 - 32); ///patratel mic sus
}

void chenar_dreapta(int poz, bool evidentiaza)
{
    poz = poz - 3;
    int x1tabla=maxx/2-dim/2;
    int y1tabla=maxy/2-dim/2;
    int x2tabla=maxx/2+dim/2;
    int y2tabla=maxy/2+dim/2;

    if(evidentiaza == 1)
        setfillstyle(1, GREEN);
    else
        setfillstyle(1, 11);
    bar(maxx - dim / 3 + 1, y1tabla + dim * (poz - 1) / 3 + 1, maxx, y1tabla + dim * (poz - 1) / 3 + 7); ///sus
    bar(maxx - dim / 3 + 1, y1tabla + dim * (poz-1) / 3 + 2, maxx - dim / 3 + 7, y1tabla + dim*poz  / 3 - 32); ///stanga
    bar(maxx, y1tabla + dim*(poz-1) / 3 + 2, maxx - 6, y1tabla + dim * poz  / 3 - 1); ///dreapta
    bar(maxx - dim / 3 + 33, y1tabla + dim * poz / 3 - 1, maxx, y1tabla + dim * poz / 3 - 7); ///jos
    bar(maxx - dim / 3 + 33, y1tabla + dim * poz / 3 - 4, maxx - dim / 3 + 39, y1tabla + dim*poz  / 3 - 36); ///laterala patratel dreapta
    bar(maxx - dim / 3 + 1, y1tabla + dim *poz  / 3 - 32, maxx - dim / 3 + 39, y1tabla + dim * poz  / 3 - 38); ///sus patratel
}


void NumarPiese(int numar, int poz)
{
    int x1tabla=maxx/2-dim/2;
    int y1tabla=maxy/2-dim/2;
    int x2tabla=maxx/2+dim/2;
    int y2tabla=maxy/2+dim/2;
    settextstyle(BOLD_FONT, 0, 3);
    setbkcolor(11);
    setcolor(BLACK);
    char c[2];
    c[0] = numar + '0';
    c[1] = NULL;
    int w2 = textwidth(c);
    int h2 = textheight(c);
    if(poz == 1)
    {
        outtextxy(dim / 3 - 16 - w2/2, y1tabla + dim / 3 - 16 - h2/2, c);
        return;
    }
    if(poz == 2)
    {
        outtextxy(dim / 3 - 16 - w2/2, y1tabla + dim * 2 / 3 - 16 - h2/2, c);
        return;
    }
    if(poz == 3)
    {
        outtextxy(dim / 3 - 16 - w2/2, y1tabla + dim - 16 - h2/2, c);
        return;
    }
    if(poz == 4)
    {
        outtextxy(maxx - dim / 3 + 16 - w2 / 2, y1tabla + dim / 3 - 16 - h2 / 2, c);
        return;
    }
    if(poz == 5)
    {
        outtextxy(maxx - dim / 3 + 16 - w2 / 2, y1tabla + dim * 2 / 3 - 16 - h2 / 2, c);
        return;
    }
    if(poz == 6)
    {
        outtextxy(maxx - dim / 3 + 16 - w2 / 2, y1tabla + dim - 16 - h2 / 2, c);
        return;
    }
}

void DesenareChenarPiese()
{
    int x1tabla=maxx/2-dim/2;
    int y1tabla=maxy/2-dim/2;
    int x2tabla=maxx/2+dim/2;
    int y2tabla=maxy/2+dim/2;

    setcolor(BLACK); ///patrate stanga pentru piese
    setfillstyle(SOLID_FILL,11);
    bar(0,y1tabla,dim/3,y1tabla+dim/3);
    rectangle(dim / 3 - 31, y1tabla + dim / 3 - 31, dim / 3 - 1, y1tabla + dim / 3 - 1);
    rectangle(dim / 3 - 32, y1tabla + dim / 3 - 32, dim / 3, y1tabla + dim / 3);


    bar(0,y1tabla+dim/3,dim/3,y1tabla+dim/3*2);
    rectangle(dim / 3 - 31, y1tabla + dim * 2 / 3 - 31, dim / 3 - 1, y1tabla + dim * 2 / 3 - 1);
    rectangle(dim / 3 - 32, y1tabla + dim * 2 / 3 - 32, dim / 3, y1tabla + dim * 2 / 3);

    bar(0,y1tabla+dim/3*2,dim/3,y1tabla+dim);
    rectangle(dim / 3 - 31, y1tabla + dim - 31, dim / 3 - 1, y1tabla + dim - 1);
    rectangle(dim / 3 - 32, y1tabla + dim - 32, dim / 3, y1tabla + dim);

    setcolor(BLACK);
    line(0,y1tabla+dim/3,dim/3,y1tabla+dim/3); ///prima linie stanga
    line(0,y1tabla+dim/3 - 1,dim/3,y1tabla+dim/3 - 1);
    line(0,y1tabla+dim/3*2,dim/3,y1tabla+dim/3*2);///a 2-a linie stanga
    line(0,y1tabla+dim/3*2 - 1,dim/3,y1tabla+dim/3*2 - 1);

    desenarePiesa(0,y1tabla        ,dim/3,y1tabla+dim/3   ,1);
    desenarePiesa(0,y1tabla+dim/3  ,dim/3,y1tabla+dim/3*2 ,2);
    desenarePiesa(0,y1tabla+dim/3*2,dim/3,y1tabla+dim     ,3);


    setfillstyle(SOLID_FILL,11); ///patrate dreapta piese
    bar(maxx-dim/3,y1tabla,maxx,y1tabla+dim/3);
    rectangle(maxx - dim / 3, y1tabla + dim / 3, maxx - dim / 3 + 32, y1tabla + dim / 3 - 32); ///numar piese -> piesa mica
    rectangle(maxx - dim / 3 - 1, y1tabla + dim / 3 - 1, maxx - dim / 3 + 31, y1tabla + dim / 3 - 31);


    bar(maxx-dim/3,y1tabla+dim/3,maxx,y1tabla+dim/3*2);
    rectangle(maxx - dim / 3, y1tabla + dim * 2 / 3, maxx - dim / 3 + 32, y1tabla + dim * 2 / 3 - 32);
    rectangle(maxx - dim / 3 - 1, y1tabla + dim * 2 / 3 - 1, maxx - dim / 3 + 31, y1tabla + dim * 2 / 3 - 31);


    bar(maxx-dim/3,y1tabla+dim/3*2,maxx,y1tabla+dim);
    rectangle(maxx - dim / 3, y1tabla + dim, maxx - dim / 3 + 32, y1tabla + dim - 32);
    rectangle(maxx - dim / 3 - 1, y1tabla + dim - 1, maxx - dim / 3 + 31, y1tabla + dim - 31);

    desenarePiesa(maxx-dim/3,y1tabla         ,maxx, y1tabla+dim/3   ,4);
    desenarePiesa(maxx-dim/3,y1tabla+dim/3   ,maxx, y1tabla+dim/3*2 ,5);
    desenarePiesa(maxx-dim/3,y1tabla+dim/3*2 ,maxx, y1tabla+dim     ,6);


    setcolor(BLACK);
    line(maxx-dim/3,y1tabla+dim/3,maxx,y1tabla+dim/3); ///prima linie dreapta
    line(maxx-dim/3,y1tabla+dim/3 - 1,maxx,y1tabla+dim/3 - 1);
    line(maxx-dim/3,y1tabla+dim/3*2,maxx,y1tabla+dim/3*2); ///a 2-a linie dreapta
    line(maxx-dim/3,y1tabla+dim/3*2 - 1,maxx,y1tabla+dim/3*2 - 1);

    rectangle(maxx - dim / 3, y1tabla, maxx, y1tabla + dim);///patratele contur pt piese
    rectangle(maxx - dim / 3 - 1, y1tabla - 1, maxx, y1tabla + dim - 1);

    rectangle(0, y1tabla, dim / 3, y1tabla + dim);
    rectangle(0, y1tabla - 1, dim / 3 - 1, y1tabla + dim - 1);

    NumarPiese(2, 1);
    NumarPiese(2, 2);
    NumarPiese(2, 3);
    NumarPiese(2, 4);
    NumarPiese(2, 5);
    NumarPiese(2, 6);

    setbkcolor(YELLOW2);
    settextstyle(BOLD_FONT, 0, 4);
    setfillstyle(1, WHITE);
    char *s;
    if(language_folosit == 0)
    {
        s = "Player 1";
    }
    else
        s = "Jucator 1";
    int wCucMic = textwidth(s);
    int hCucMic = textheight(s);
    outtextxy((2+dim/3)/2 - wCucMic/2, 15, s);
    rectangle((2+dim/3)/2 - wCucMic/2 - 2, 13, (2+dim/3)/2 + wCucMic/2 + 2, 17 + hCucMic);
    rectangle((2+dim/3)/2 - wCucMic/2 - 1, 14, (2+dim/3)/2 + wCucMic/2 + 1, 16 + hCucMic);

    if(language_folosit == 0)
    {
        s = "Player 2";
    }
    else
        s = "Jucator 2";
    outtextxy((2*maxx - dim/3)/2 - wCucMic/2, 15, s);
    rectangle((2*maxx - dim/3)/2 - wCucMic/2 - 2, 13, (2*maxx - dim/3)/2 + wCucMic/2 + 2, 17 + hCucMic);
    rectangle((2*maxx - dim/3)/2 - wCucMic/2 - 1, 14, (2*maxx - dim/3)/2 + wCucMic/2 + 1, 16 + hCucMic);

}







//AAAAAAAAAAAAA

void clearpatrat(int i, int j) {
    setfillstyle(SOLID_FILL,9);
    bar(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2);
}
void initializare() {
    for (int i=1;i<=3;i++)
        for (int j=1;j<=3;j++) {
            for (int k=0;k<=3;k++) {
                tabla[i][j].adancime[tabla[i][j].index] = 0;
            }
            tabla[i][j].index=0;
        }
    piesaselectata=0;
    piesaplasata=0;
    turn=1;
    ok=0;
    memorie=0;
    for (int i=1;i<=6;i++) {
        frecPiese[i]=2;
    }
    win=0;
}
void gasestexytab(int &x,int &y) {

    for (int i=1;i<=3;i++) {
        for (int j=1;j<=3;j++) {
            if (x>=tabla[i][j].x1&&x<=tabla[i][j].x2)
                if (y>=tabla[i][j].y1&&y<=tabla[i][j].y2) {
                    x=i;
                    y=j;
                    return;
                }
        }
    }
    x=0;
    y=0;
}
int gasesteVec(int x, int y) {
    for (int i=1;i<=6;i++) {
        if (x>=v[i].x1&&x<=v[i].x2)
            if (y>=v[i].y1&&y<=v[i].y2)
                return i;
    }
    return 0;
}
void departajareMatrice() {
    int x1tabla=maxx/2-dim/2, y1tabla=maxy/2-dim/2,x2tabla=maxx/2+dim/2, y2tabla=maxy/2+dim/2;
    int dimpat=200;
    int x=maxx/2-dim/2;
    int y=maxy/2-dim/2;
    for (int i=1;i<=3;i++) {
        for (int j=1;j<=3;j++) {
            tabla[i][j].x1= x+1;
            tabla[i][j].x2= x+dimpat-1;
            tabla[i][j].y1= y+1;
            tabla[i][j].y2= y+dimpat-1;
            x=x+dimpat;
        }
        x=maxx/2-dim/2;
        y=y+dimpat;
    }
}
void valoarePiese() {
    for (int i=1;i<=6;i++) {
        if (i>3) {
            v[i].valoare=i-3;
        }
        else v[i].valoare=i;
    }
}
void departajarePiese() {
    int y1tabla=maxy/2-dim/2, y2tabla=maxy/2+dim/2;
    int x=0, y=y1tabla;
    int j=1;
    for (int i=1;i<=6;i++) {
        if (i==4) {
            x=maxx-dim/3;
            y=y1tabla;
        }
        v[i].x1=x;
        v[i].x2=x+dim/3;
        v[i].y1=y;
        v[i].y2=y+dim/3;
        y=y+dim/3;
    }

}
void randmutare(int i) {

    int wCucMic = textwidth("Player 1");
    int hCucMic = textheight("Player 1");
    setfillstyle(1, YELLOW2);
    bar((2+dim/3)/2 + wCucMic - 3, hCucMic/2, (2*maxx - dim/3)/2 - wCucMic + 3, 30 + hCucMic/2);

    if (i%2==1) {

        sagetutza_player_1((2+dim/3)/2 + wCucMic, 15 + hCucMic/2);

    }
    else {
        sagetutza_player_2((2*maxx - dim/3)/2 - wCucMic, 15 + hCucMic/2);
    }
}
void eroare() {
    setbkcolor(YELLOW2);
    readimagefile("eroare.gif",maxx/2,maxy/2-dim/2-50,maxx/2+50,maxy/2-dim/2-10);
    setfillstyle(SOLID_FILL,5);

}
void testmatrice () {
    for (int i=1;i<=3;i++)
        for (int j=1;j<=3;j++) {
            setfillstyle(SOLID_FILL,BLACK);
            bar(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2);
            delay(500);
        }
}
void cleareroare() {
    setfillstyle(SOLID_FILL,YELLOW2);
    bar(maxx/2,maxy/2-dim/2-50,maxx/2+50,maxy/2-dim/2-10);
}
void verificare_castigator() {
    int castigator=0;
    for (int i=1;i<=3;i++) {
        int x=tabla[i][1].adancime[tabla[i][1].index];
        int y=tabla[i][2].adancime[tabla[i][2].index];
        int z=tabla[i][3].adancime[tabla[i][3].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;
            cout<<"Castigator caz1: "<<x<<" "<<y<<" "<<z;
        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;
            cout<<"Castigator caz2: "<<x<<" "<<y<<" "<<z;
        }
    }
    for (int i=1;i<=3;i++) {
        int x=tabla[1][i].adancime[tabla[1][i].index];
        int y=tabla[2][i].adancime[tabla[2][i].index];
        int z=tabla[3][i].adancime[tabla[3][i].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;
            cout<<"Castigator caz3: "<<x<<" "<<y<<" "<<z;
        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;
            cout<<"Castigator caz4: "<<x<<" "<<y<<" "<<z;
        }
    }
    if (!castigator) {

        int x=tabla[1][1].adancime[tabla[1][1].index];
        int y=tabla[2][2].adancime[tabla[2][2].index];
        int z=tabla[3][3].adancime[tabla[3][3].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;
            cout<<"Castigator caz5: "<<x<<" "<<y<<" "<<z;

        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;
            cout<<"Castigator caz6: "<<x<<" "<<y<<" "<<z;

        }

        x=tabla[1][3].adancime[tabla[1][3].index];
        y=tabla[2][2].adancime[tabla[2][2].index];
        z=tabla[3][1].adancime[tabla[3][1].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;
            cout<<"Castigator caz7: "<<x<<" "<<y<<" "<<z;
        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;
            cout<<"Castigator caz8: "<<x<<" "<<y<<" "<<z;
        }
    }
    if (castigator) {
        win=1;
        desencastig();
        you_won(castigator);
    }
}
int cpiece(int i, int j) {
    if (tabla[i][j].adancime[tabla[i][j].index]>=4&&tabla[i][j].adancime[tabla[i][j].index]<=6)
        return 1;
    return 0;
}
int cpiece2 (int i, int j, int num) {
    if (tabla[i][j].adancime[tabla[i][j].index]==num)
        return 1;
    else return 0;
}
int cpiece3 (int i, int j) {
    if (tabla[i][j].adancime[tabla[i][j].index]>=1&&tabla[i][j].adancime[tabla[i][j].index]<=3)
        return 0;
    else return 1;
}
void scr(int& a, int& b,int k, int& score) {
    score = 0;
    for (int i=1;i<=3;i++)
        for (int j=1;j<=3;j++) {
            if (cpiece2(i,j,5)) score= score +2;
            else if (cpiece2(i,j,5)) score= score +1;
        }

    for (int i=1;i<=3;i++) {
        if (cpiece(i,1)&&cpiece(i,2)) score= score+2;
        if (cpiece(i,1)&&cpiece(i,3)) score= score+2;   //orizontal
        if (cpiece(i,2)&&cpiece(i,3)) score= score+2;


        if (cpiece(1,i)&&cpiece(2,i)) score= score+2;
        if (cpiece(2,i)&&cpiece(3,i)) score= score+2;   //vertical
        if (cpiece(1,i)&&cpiece(3,i)) score= score+2;
    }

    if (cpiece2(2,2,6)) score = score +6;               //mijloc

    if (cpiece(1,1)&&cpiece(2,2)) score = score+2;
    if (cpiece(1,1)&&cpiece(3,3)) score = score+2;      //diag prin
    if (cpiece(2,2)&&cpiece(3,3)) score = score+2;

    if (cpiece(3,1)&&cpiece(1,3)) score = score+2;
    if (cpiece(2,2)&&cpiece(1,3)) score = score+2;      //diag sec
    if (cpiece(2,2)&&cpiece(3,1)) score = score+2;

    if (cpiece(1,1)&&cpiece(3,3)&&cpiece(1,3)) score = score +8;
    if (cpiece(1,1)&&cpiece(3,3)&&cpiece(3,1)) score = score +8;     //forma de L (castig la 2 capete)
    if (cpiece(1,1)&&cpiece(3,3)&&cpiece(3,3)) score = score +8;

    if (cpiece(2,2)&&cpiece(1,1)&&cpiece(1,3)) score = score +8;
    if (cpiece(2,2)&&cpiece(1,1)&&cpiece(3,1)) score = score +8;
    if (cpiece(2,2)&&cpiece(3,3)&&cpiece(1,3)) score = score +8;
    if (cpiece(2,2)&&cpiece(3,3)&&cpiece(3,1)) score = score +8;

    //VERIFICARI POSIBILITATI CASTIG
    if (cpiece(1,1)&&cpiece(1,2)&&cpiece(1,3)) score = score +200;
    if (cpiece(2,1)&&cpiece(2,2)&&cpiece(2,3)) score = score +200;      //orizontal
    if (cpiece(3,1)&&cpiece(3,2)&&cpiece(3,3)) score = score +200;

    if (cpiece(1,1)&&cpiece(2,1)&&cpiece(3,1)) score = score +200;
    if (cpiece(1,2)&&cpiece(2,2)&&cpiece(3,2)) score = score +200;      //vertical
    if (cpiece(1,3)&&cpiece(2,3)&&cpiece(3,3)) score = score +200;

    if (cpiece(1,1)&&cpiece(2,2)&&cpiece(3,3)) score = score +200;
    if (cpiece(1,3)&&cpiece(2,2)&&cpiece(3,1)) score = score +200;

}
void detectarePozCastigatoare(int& castig) {
    int castigator=0, ok=0;
    for (int i=1;i<=3;i++)
        for (int j=1;j<=3;j++) {
            if (tabla[i][j].adancime[tabla[i][j].index]!=3&&tabla[i][j].adancime[tabla[i][j].index]!=6&&ok==0) {
                tabla[i][j].index++;
                tabla[i][j].adancime[tabla[i][j].index]=3;
                castigatC(castigator);
                tabla[i][j].index--;
                if (castigator) {
                    castig=1;
                    ok=1;
                    desenarePiesa(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2, tabla[i][j]. adancime[tabla[i][j].index]++);
                }
            }
        }

}

void castigatC(int &castigator) {
    castigator=0;
    for (int i=1;i<=3;i++) {
        int x=tabla[i][1].adancime[tabla[i][1].index];
        int y=tabla[i][2].adancime[tabla[i][2].index];
        int z=tabla[i][3].adancime[tabla[i][3].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;
        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;

        }
    }
    for (int i=1;i<=3;i++) {
        int x=tabla[1][i].adancime[tabla[1][i].index];
        int y=tabla[2][i].adancime[tabla[2][i].index];
        int z=tabla[3][i].adancime[tabla[3][i].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;
        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;
        }
    }
    if (!castigator) {

        int x=tabla[1][1].adancime[tabla[1][1].index];
        int y=tabla[2][2].adancime[tabla[2][2].index];
        int z=tabla[3][3].adancime[tabla[3][3].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;

        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;

        }

        x=tabla[1][3].adancime[tabla[1][3].index];
        y=tabla[2][2].adancime[tabla[2][2].index];
        z=tabla[3][1].adancime[tabla[3][1].index];
        if (x<4&&y<4&&z<4&&x&&y&&z) {
            castigator=1;
        }
        else if (x>3&&y>3&&z>3) {
            castigator=2;
        }
    }
}
void detectarecomp(int& pozComputer, int &a, int &b) {
    int castigator;
    for (int i=1 ; i<=3 ; i++) {
        for (int j=1 ; j<=3; j++) {
            int aux = tabla[i][j].adancime[tabla[i][j].index];
            if (aux!=3) {
                tabla[i][j].index ++;
                tabla[i][j].adancime[tabla[i][j].index] = 6;
                castigatC(castigator);
                if (castigator==2) {
                    if (aux == 1) {
                        if (frecPiese[5]||frecPiese[6]) {
                            a=i;
                            b=j;
                            pozComputer=1;
                        }
                    }
                    else if (aux==2) {
                        if (frecPiese[6]) {
                            a=i;
                            b=j;
                            pozComputer=1;
                        }
                    }
                    else if (aux==0) {
                        a=i;
                        b=j;
                        pozComputer=1;
                    }
                }
                tabla[i][j].adancime[tabla[i][j].index] = 0;
                tabla[i][j].index--;
            }
        }
    }
    if (a) cout<<"a b =" <<a <<" "<<b;
}
void detectareplayer(int& pozPlayer, int &a, int &b) {
    int castigator;
    for (int i=1 ; i<=3 ; i++) {
        for (int j=1 ; j<=3; j++) {
            int aux = tabla[i][j].adancime[tabla[i][j].index];
            if (aux!=3) {
                tabla[i][j].index ++;
                tabla[i][j].adancime[tabla[i][j].index] = 3;
                castigatC(castigator);
                if (castigator==1) {
                    if (aux == 0) {
                        if (frecPiese[5]||frecPiese[6]||frecPiese[4]) {
                            a=i;
                            b=j;
                            pozPlayer=1;
                        }
                    }
                    else if (aux==4) {
                        if (( frecPiese[2] ||  frecPiese[3]) && (frecPiese[5] || frecPiese[6])) {
                            a=i;
                            b=j;
                            pozPlayer=1;
                        }
                    }
                    else if (aux==5) {
                        if ((frecPiese[3] && frecPiese[6])) {
                            a=i;
                            b=j;
                            pozPlayer=1;
                        }
                    }
                }
                tabla[i][j].adancime[tabla[i][j].index] = 0;
                tabla[i][j].index--;
            }
        }
        if (a) cout<<"a b =" <<a <<" "<<b;
    }
}
void mutareRandom (int& ok1) {
    ok1=0;
    int piesa_plasata=0, piesa_selectata=0,pozRamase=0, pieseRamase=0;
    int a=1, b=0, aux=0;
    for (int i=1;i<=3;i++) {
        for (int j=1;j<=3;j++) {
            if (tabla[i][j].adancime[tabla[i][j].index]==0)
                pozRamase=1;
        }
    }
    for (int i=4;i<=6;i++) {
        if (frecPiese[i]>0)
            pieseRamase=1;
    }

    if (!pozRamase||!pieseRamase) {
        cout<<"Nu mai sunt pozitii ramase"<<endl;
        while (!piesa_plasata) {
            int i= rand() % 3 + 1;
            int j= rand() % 3 + 1;
            if(!piesa_selectata) {
                if (tabla[i][j].adancime[tabla[i][j].index] >=5 && tabla[i][j].adancime[tabla[i][j].index] <=6) {
                        a=i;
                        b=j;
                        aux= tabla[a][b].adancime[tabla[a][b].index];
                        piesa_selectata=1;
                        cout<<"AUX= "<<aux<<endl;
                }
            }
            else if (v[aux].valoare>v[tabla[i][j].adancime[tabla[i][j].index]].valoare) {
                    cout<<"Calc pune piesa "<<aux <<" pe "<< i <<" "<<j<<endl;
                    tabla[i][j].index++;
                    tabla[i][j].adancime[tabla[i][j].index] = aux;
                    tabla[a][b].adancime[tabla[a][b].index]= 0;
                    tabla[a][b].index--;
                    desenarePiesa(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2, aux);
                    clearpatrat(a, b);
                    desenarePiesa(tabla[a][b].x1,tabla[a][b].y1,tabla[a][b].x2,tabla[a][b].y2, tabla[a][b].adancime[tabla[a][b].index]);
                    ok1=1;
                    piesa_plasata=1;
                }
            }
    }
    else {
    int i, j, p;
    while(!ok1) {
        i= rand() % 3 +1;
        j= rand() % 3 +1;
        if (tabla[i][j].adancime[tabla[i][j].index]) {
            int auxi = tabla[i][j].adancime[tabla[i][j].index];
            if (auxi>=0&&auxi<=2) {
                if (frecPiese[auxi+4]) {
                    desenarePiesa(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2, auxi+4);
                    frecPiese[auxi+4]--;
                    NumarPiese(frecPiese[auxi+4],auxi+4);
                    tabla[i][j].index++;
                    tabla[i][j].adancime[tabla[i][j].index]= auxi+4;
                    ok1=1;
                    cout<<"C: "<<i<<" "<<j<<" "<<  auxi+4<<endl;
                }
            }
        }
        else {
            if (frecPiese[6]) {
                desenarePiesa(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2, 6);
                    frecPiese[6]--;
                    NumarPiese(frecPiese[6],6);
                    tabla[i][j].index++;
                    tabla[i][j].adancime[tabla[i][j].index]= 6;
                    ok1=1;
            }
            else if (frecPiese[5]) {
                desenarePiesa(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2, 5);
                    frecPiese[5]--;
                    NumarPiese(frecPiese[5],5);
                    tabla[i][j].index++;
                    tabla[i][j].adancime[tabla[i][j].index]= 5;
                    ok1=1;
            }
            else if (frecPiese[4]) {
                desenarePiesa(tabla[i][j].x1,tabla[i][j].y1,tabla[i][j].x2,tabla[i][j].y2, 4);
                    frecPiese[4]--;
                    NumarPiese(frecPiese[4],4);
                    tabla[i][j].index++;
                    tabla[i][j].adancime[tabla[i][j].index]= 4;
                    ok1=1;
            }
        }
    }
    }

}
void desencastig() {
    cout<<endl;
    for (int i=1;i<=3;i++) {
        for (int j=1;j<=3;j++)
            cout<<tabla[i][j].adancime[tabla[i][j].index]<<" ";
        cout<<endl;
    }
}


void joc(int x, int y)
{
    sageata_pentru_joc(x, y);
    int registru;
    if (piesaselectata==0) {
        registru=gasesteVec(mousex(),mousey());
        int xv=x, yv=y;
        gasestexytab(xv,yv);
        if (registru) {
            cout<<registru<<" "<<endl;
            if ((registru>0&&registru<4)&&turn%2==0) {
                eroare();
                cout<<"Piesa invalida(rand jucator 2)"<<endl;
            }
            else if ((registru>3&&registru<7)&&turn%2==1) {
                eroare();
                cout<<"Piesa invalida(rand jucator 1)"<<endl;
            }
            else if (frecPiese[registru]<1) {
                eroare();
                cout<<"Piese insuficiente ramase"<<endl;
            }
            else {
                memorie=registru;
                frecPiese[registru]--;
                NumarPiese(frecPiese[registru], registru);
                piesaselectata=1;
                cleareroare();
                if(turn % 2 == 1)
                    chenar_stanga(memorie, 1);
                else
                    chenar_dreapta(memorie, 1);

            }
        }
        else if (xv) {
            if (tabla[xv][yv]. adancime[tabla[xv][yv].index]>0&&tabla[xv][yv]. adancime[tabla[xv][yv].index]<4 && turn%2!=1) {
                eroare();
                cout<<"Piesa nu apartine jucatorului corect"<<endl;
            }
            else if (tabla[xv][yv]. adancime[tabla[xv][yv].index]>3&& turn%2!=0) {
                eroare();
                cout<<"Piesa nu apartine jucatorului corect"<<endl;
            }
            else if (!tabla[xv][yv].index) {
                eroare();
                cout<<"Piesa nu exista";
            }
            else {
                 memorie= tabla[xv][yv]. adancime[tabla[xv][yv].index];
                 tabla[xv][yv].index--;
                 clearpatrat(xv,yv);
                 desenarePiesa(tabla[xv][yv].x1,tabla[xv][yv].y1,tabla[xv][yv].x2,tabla[xv][yv].y2, tabla[xv][yv]. adancime[tabla[xv][yv].index]);
                 piesaselectata=1;
                 cleareroare();
            }
        }
    cout<<"RAND1: "<<turn<<endl;
    }
    else {
        int xm=x, ym=y;
        gasestexytab(xm,ym);
        cout<<xm<<" "<<ym<<" "<<endl;
        if (xm) {
            if (tabla[xm][ym].index==0) {
                desenarePiesa(tabla[xm][ym].x1, tabla[xm][ym].y1, tabla[xm][ym].x2, tabla[xm][ym].y2, memorie);
                tabla[xm][ym].index++;
                turn++;
                tabla[xm][ym].adancime[tabla[xm][ym].index]=memorie;
                piesaselectata=0;


            }
            else if (tabla[xm][ym].index!=0) {
                if (v[memorie].valoare>v[tabla[xm][ym].adancime[tabla[xm][ym].index]].valoare) {
                    clearpatrat(xm, ym);
                    desenarePiesa(tabla[xm][ym].x1,tabla[xm][ym].y1,tabla[xm][ym].x2,tabla[xm][ym].y2, memorie);
                    tabla[xm][ym].index++;
                    tabla[xm][ym].adancime[tabla[xm][ym].index] = memorie;
                    piesaselectata=0;
                    turn++;
                    cleareroare();
                }
                else {
                    eroare();
                    cout<<" Piesa de pe pozitia "<<xm<<" "<<ym<<" este mai mare decat selectata "<<endl;
                    cout<<v[memorie].valoare<<" "<<v[tabla[xm][ym].adancime[tabla[xm][ym].index]].valoare<<endl;
                }
            }
        }
        if(turn % 2 == 0)
            chenar_stanga(memorie, 0);
        else
            chenar_dreapta(memorie, 0);
        randmutare(turn);
        verificare_castigator();
    }
    cout<<"RAND2: "<<turn<<endl;
}


void castigplayer(int pozPlayer, int a1, int b1) {
                if (pozPlayer==1) {
                    cout<<"WIN "<<endl;
                    int aux= tabla[a1][b1].adancime[tabla[a1][b1].index];
                    if (aux == 0) {
                        tabla[a1][b1].index++;
                        if (frecPiese[6]) {
                            tabla[a1][b1].index++;
                            frecPiese[6]--;
                            NumarPiese(frecPiese[6], 6);
                            tabla[a1][b1].adancime[tabla[a1][b1].index] = 6;
                            desenarePiesa(tabla[a1][b1].x1,tabla[a1][b1].y1,tabla[a1][b1].x2,tabla[a1][b1].y2,6);
                            turn++;
                        }
                        else if (frecPiese[5]) {
                            tabla[a1][b1].index++;
                            frecPiese[5]--;
                            NumarPiese(frecPiese[5], 5);
                            tabla[a1][b1].adancime[tabla[a1][b1].index] = 5;
                            desenarePiesa(tabla[a1][b1].x1,tabla[a1][b1].y1,tabla[a1][b1].x2,tabla[a1][b1].y2,5);
                            turn++;
                        }
                        else if (frecPiese[4]) {
                            tabla[a1][b1].index++;
                            frecPiese[4]--;
                            NumarPiese(frecPiese[4], 4);
                            tabla[a1][b1].adancime[tabla[a1][b1].index] = 4;
                            desenarePiesa(tabla[a1][b1].x1,tabla[a1][b1].y1,tabla[a1][b1].x2,tabla[a1][b1].y2,4);
                            turn++;
                        }
                    }
                    else {
                        if (aux==2||aux==1) {
                            if (frecPiese[5]) {
                                tabla[a1][b1].index++;
                                frecPiese[5]--;
                                NumarPiese(frecPiese[5], 5);
                                tabla[a1][b1].adancime[tabla[a1][b1].index] = 5;
                                desenarePiesa(tabla[a1][b1].x1,tabla[a1][b1].y1,tabla[a1][b1].x2,tabla[a1][b1].y2,5);
                                turn++;
                            }
                            else if (frecPiese[6]) {
                                tabla[a1][b1].index++;
                                frecPiese[6]--;
                                NumarPiese(frecPiese[6], 6);
                                tabla[a1][b1].adancime[tabla[a1][b1].index] = 6;
                                desenarePiesa(tabla[a1][b1].x1,tabla[a1][b1].y1,tabla[a1][b1].x2,tabla[a1][b1].y2,6);
                                turn++;
                            }
                        }
                    }
                }
}
void alegepiesa(int p, int& a, int& b)  {
    int contor=0;
    int a1=0, b1=0;
    for (int i=1;i<=3;i++)
        for (int j=1;j<=3;j++) {
            if (cpiece2(i,j,p)) {
                if(contor==0) {
                    contor++;
                    a= i;
                    b= j;
                }
                else {
                    a1= i;
                    b1= j;
                }
            }
        }
    int score1=0, score2=0, aux=0;
    aux = tabla[a][b].adancime[tabla[a][b].index];
    tabla[a][b].adancime[tabla[a][b].index]=0;
    tabla[a][b].index--;
    scr(a, b , p, score1);
    tabla[a][b].index++;
    tabla[a][b].adancime[tabla[a][b].index]= aux;
    if (a1) {
        aux = tabla[a1][b1].adancime[tabla[a1][b1].index];
        tabla[a1][b1].adancime[tabla[a1][b1].index]=0;
        tabla[a1][b1].index--;
        scr(a1, b1 , p, score1);
        tabla[a1][b1].index++;
        tabla[a1][b1].adancime[tabla[a1][b1].index]= aux;
    }
    if (score2>score1) {
        a= a1;
        b= b1;
    }

}
void joccomputer (int x, int y) {
    sageata_pentru_joc(x, y);
    int registru;
    if (turn%2==1) {
        if (piesaselectata==false) {    //      selectare piesa din matrice
            registru=gasesteVec(mousex(),mousey());
            int xv=x, yv=y;
            gasestexytab(xv,yv);
            if (registru) {
            if ((registru>0&&registru<4)&&turn%2==0) {
                eroare();
                cout<<"Piesa invalida(rand jucator 2)"<<endl;
            }
            else if ((registru>3&&registru<7)&&turn%2==1) {
                eroare();
                cout<<"Piesa invalida(rand jucator 1)"<<endl;
            }
            else if (frecPiese[registru]<1) {
                eroare();
                cout<<"Piese insuficiente ramase"<<endl;
            }
            else {
                memorie=registru;
                frecPiese[registru]--;
                NumarPiese(frecPiese[registru], registru);
                piesaselectata=1;
                cleareroare();
                chenar_stanga(memorie,1);
            }
        }
        else if (xv) {          // selectare piesa din matrice
            if (tabla[xv][yv]. adancime[tabla[xv][yv].index]>0&&tabla[xv][yv]. adancime[tabla[xv][yv].index]<4 && turn%2!=1) {
                eroare();
                cout<<"Piesa nu apartine jucatorului corect"<<endl;
            }
            else if (tabla[xv][yv]. adancime[tabla[xv][yv].index]>3&& turn%2!=0) {
                eroare();
                cout<<"Piesa nu apartine jucatorului corect"<<endl;
            }
            else if (!tabla[xv][yv].index) {
                eroare();
                cout<<"Piesa nu exista";
            }
            else {
                 memorie= tabla[xv][yv]. adancime[tabla[xv][yv].index];
                 tabla[xv][yv]. adancime[tabla[xv][yv].index] = 0;
                 tabla[xv][yv].index--;
                 clearpatrat(xv,yv);
                 desenarePiesa(tabla[xv][yv].x1,tabla[xv][yv].y1,tabla[xv][yv].x2,tabla[xv][yv].y2, tabla[xv][yv]. adancime[tabla[xv][yv].index]);
                 piesaselectata=1;
                 cleareroare();
                }
            }
        }
        else {              // plasare piesa
            int xm=x, ym=y;
        gasestexytab(xm,ym);
        if (xm) {
            if (tabla[xm][ym].index==0) {
                desenarePiesa(tabla[xm][ym].x1, tabla[xm][ym].y1, tabla[xm][ym].x2, tabla[xm][ym].y2, memorie);
                tabla[xm][ym].index++;
                turn++;
                tabla[xm][ym].adancime[tabla[xm][ym].index]=memorie;
                piesaselectata=0;

            }
            else if (tabla[xm][ym].index!=0) {
                if (v[memorie].valoare>v[tabla[xm][ym].adancime[tabla[xm][ym].index]].valoare) {
                    clearpatrat(xm, ym);
                    desenarePiesa(tabla[xm][ym].x1,tabla[xm][ym].y1,tabla[xm][ym].x2,tabla[xm][ym].y2, memorie);
                    tabla[xm][ym].index++;
                    tabla[xm][ym].adancime[tabla[xm][ym].index] = memorie;
                    piesaselectata=0;
                    turn++;
                    cleareroare();
                }
                else {
                    eroare();
                    cout<<" Piesa de pe pozitia "<<xm<<" "<<ym<<" este mai mare decat selectata "<<endl;
                    cout<<v[memorie].valoare<<" "<<v[tabla[xm][ym].adancime[tabla[xm][ym].index]].valoare<<endl;
                }
            }
            chenar_stanga(memorie, 0);
        }
        verificare_castigator();
        if (!win) {
            delay(100);
            if (turn%2==0) {
                int pozPlayer=0, pozComputer=0, a=0, b=0, a1=0, b1=0, mutare_realizata=0;
                if (proMODE==1&&turn%2==0) {
                    if (proMODE==1) {
                        scoremax=0;
                        for (int i=1;i<=3;i++)
                            for (int j=1;j<=3;j++) {
                                for (int k=4;k<=6;k++) {
                                    int aux = tabla[i][j].adancime[tabla[i][j].index];
                                    int a=0, b=0, score=0;
                                    if (!cpiece2(i,j,3)&&!cpiece2(i,j,6)&&v[k].valoare>v[aux].valoare) {
                                        tabla[i][j].index++;
                                        tabla[i][j].adancime[tabla[i][j].index] = k;
                                        scr(a,b,k,score);
                                        if (score > scoremax) {
                                            scoremax= score;
                                            ac = i;
                                            bc = j;
                                            kc = k;
                                        }
                                        tabla[i][j].adancime[tabla[i][j].index]= 0;
                                        tabla[i][j].index--;
                                    }
                                }
                            }
                        cout<<"SCORE : "<<scoremax<<endl;
                        if (scoremax>=200) {
                            if (frecPiese[kc]) {
                                tabla[ac][bc].index++;
                                tabla[ac][bc].adancime[tabla[ac][bc].index] = kc;
                                desenarePiesa(tabla[ac][bc].x1,tabla[ac][bc].y1,tabla[ac][bc].x2,tabla[ac][bc].y2,kc);
                                frecPiese[kc]--;
                                NumarPiese(frecPiese[kc], kc);
                                turn++;
                                cout<<"PIESA " <<ac<<" "<<bc<<" "<<kc<<endl;
                            }
                            else {
                                a=0, b=0;
                                alegepiesa(kc, a, b);
                                tabla[a][b].adancime[tabla[a][b].index]= 0;
                                tabla[a][b].index--;
                                clearpatrat(a,b);
                                desenarePiesa(tabla[a][b].x1,tabla[a][b].y1,tabla[a][b].x2,tabla[a][b].y2,tabla[a][b].adancime[tabla[a][b].index]);
                                verificare_castigator();
                                tabla[ac][bc].index++;
                                tabla[ac][bc].adancime[tabla[ac][bc].index]= kc;
                                desenarePiesa(tabla[ac][bc].x1,tabla[ac][bc].y1,tabla[ac][bc].x2,tabla[ac][bc].y2,tabla[ac][bc].adancime[tabla[ac][bc].index]);
                                turn++;
                            }
                        }
                        else {
                            detectareplayer(pozPlayer, a, b);
                            if (pozPlayer==1) {
                                castigplayer(pozPlayer, a, b);
                                cout<<"CASTIG PLAYER : "<<endl;
                            }
                            else {
                                if (frecPiese[kc]) {
                                    tabla[ac][bc].index++;
                                    tabla[ac][bc].adancime[tabla[ac][bc].index] = kc;
                                    desenarePiesa(tabla[ac][bc].x1,tabla[ac][bc].y1,tabla[ac][bc].x2,tabla[ac][bc].y2,kc);
                                    frecPiese[kc]--;
                                    NumarPiese(frecPiese[kc], kc);
                                    turn++;
                                }
                                else {
                                    a=0, b=0;
                                    alegepiesa(kc, a, b);
                                    tabla[a][b].adancime[tabla[a][b].index]= 0;
                                    tabla[a][b].index--;
                                    clearpatrat(a,b);
                                    desenarePiesa(tabla[a][b].x1,tabla[a][b].y1,tabla[a][b].x2,tabla[a][b].y2,tabla[a][b].adancime[tabla[a][b].index]);
                                    verificare_castigator();
                                    tabla[ac][bc].index++;
                                    tabla[ac][bc].adancime[tabla[ac][bc].index]= kc;
                                    desenarePiesa(tabla[ac][bc].x1,tabla[ac][bc].y1,tabla[ac][bc].x2,tabla[ac][bc].y2,tabla[ac][bc].adancime[tabla[ac][bc].index]);
                                    turn++;
                                }

                            }
                        }
                    }
                }
                else if (turn%2==0&&proMODE==0){
                        cout<<"RANDOM3: "<<endl;
                        mutareRandom(mutare_realizata);
                        turn++;
                }
            }
        }
            verificare_castigator();
    }
}

}
void incepejoc() {
    randmutare(turn);
    registermousehandler(WM_LBUTTONDOWN,joc);
}

void init() {
    valoarePiese();
    departajareMatrice();
    departajarePiese();
    initializare();
}
void sageata_pentru_joc_desen()
{
    int ya = maxy / 18;
    int yb = maxy / 22;
    readimagefile("sageata2.jpg",ya, maxy - ya - 10, 2 * ya, maxy - 10);
    rectangle(ya, maxy - ya - 10, 2 * ya, maxy - 10);
}
void sageata_pentru_joc(int x, int y)
{
    int ya = maxy / 18;
    int yb = maxy / 22;
    int mx = x;
    int my = y;
    if(mx >= ya && mx <= 2 * ya && my >= maxy - ya - 10 && my <= maxy - 10) ///buton catre tabla de joc
    {
        cleardevice();
        graficaoponent();
        registermousehandler(WM_LBUTTONDOWN,opponent);
    }
}
void grafica() {
    TablaJoc();
    DesenareChenarPiese();
    sageata_pentru_joc_desen();
    if (playertwo==0) randmutare(turn);
}




