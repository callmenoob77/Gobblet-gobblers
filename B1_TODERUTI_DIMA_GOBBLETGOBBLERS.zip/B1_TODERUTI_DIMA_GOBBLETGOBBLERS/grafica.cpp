#include <graphics.h>
using namespace std;
int maxx, maxy;
int dim= 600;
#define YELLOW2 RGB(242,121,121)
void Window()
{
    DWORD screenWidth = GetSystemMetrics(SM_CXSCREEN);
    DWORD screenHeight = GetSystemMetrics(SM_CYSCREEN);
    initwindow(screenWidth, screenHeight, "", -3, -3);
    setbkcolor(10);
    maxx=getmaxx();
    maxy=getmaxy();
    cleardevice();
}
int dimPiesa(int i){
    if (i==1||i==4) return 60;
    if (i==2||i==5) return 40;
    if (i==3||i==6) return 0;
    return 0;
}

void desenarePiesa(int x1, int y1, int x2, int y2, int i) {
    int dime=dimPiesa(i);
    if (i>0&&i<4)
        readimagefile("g1.gif",x1+dime,y1+dime,x2-dime,y2-dime);
    else if (i>3&&i<7) readimagefile("g2.gif",x1+dime,y1+dime,x2-dime,y2-dime);

}


void TablaJoc()
{

    int x1tabla=maxx/2-dim/2, y1tabla=maxy/2-dim/2,x2tabla=maxx/2+dim/2, y2tabla=maxy/2+dim/2;
    setfillstyle(SOLID_FILL,YELLOW2);
    bar(0,0,maxx,maxy);
    setfillstyle(SOLID_FILL,BLACK);
    bar(x1tabla-2,y1tabla-2,x2tabla+2,y2tabla+2);
    setfillstyle(SOLID_FILL,9);
    bar(x1tabla,y1tabla,x2tabla,y2tabla);

    setcolor(BLACK);
    line(x1tabla+200,y1tabla,x1tabla+200,y2tabla);  
    line(x2tabla-200,y1tabla,x2tabla-200,y2tabla);
    line(x1tabla+199,y1tabla,x1tabla+199,y2tabla);  
    line(x2tabla-201,y1tabla,x2tabla-201,y2tabla);

    setcolor(BLACK);
    line(x1tabla,y1tabla+200,x2tabla,y1tabla+200);
    line(x1tabla,y2tabla-200,x2tabla,y2tabla-200);
    line(x1tabla,y1tabla+199,x2tabla,y1tabla+199);
    line(x1tabla,y2tabla-201,x2tabla,y2tabla-201);

}